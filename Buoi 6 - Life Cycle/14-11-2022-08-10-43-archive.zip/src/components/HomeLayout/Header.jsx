//rcc
import React, { Component } from 'react'

export default class Header extends Component {
  render() {
    return (
      <div className='bg-dark text-center text-light p-5'>
        Header component
      </div>
    )
  }
}
