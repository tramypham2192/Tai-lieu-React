import React, { Component } from 'react'

export default class Content extends Component {
  render() {
    return (
      <div className='bg-success text-white text-center p-5'>Content</div>
    )
  }
}
