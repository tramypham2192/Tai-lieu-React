import React, { Component } from 'react'

export default class Navigation extends Component {
  render() {
    return (
        <div className='bg-danger text-white text-center p-5'>Navigation</div>
    )
  }
}
