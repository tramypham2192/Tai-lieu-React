//rxlice

import { createSlice } from '@reduxjs/toolkit'

const initialState = {
    arrProduct: [
        {id:1,name:'product1',image:'https://i.pravatar.cc?u=1',price:1000},
        {id:2,name:'product2',image:'https://i.pravatar.cc?u=2',price:2000},
    ]
}

const productReducer = createSlice({
  name: 'productReducer', //Tên reducer
  initialState, //giá trị state mặc định
  reducers: {
    getAllProductApi: (state,action) => {
        state.arrProduct = action.payload;
    } 
  }
});

export const {getAllProductApi} = productReducer.actions

export default productReducer.reducer






// let number = '1';

// switch(number) {
//     case '1': {
//         return 'số một';
//     }
//     case '2': {
//         return 'số hai';
//     }
// }


// const docSo = {
//     '1': 'Số một',
//     '2': 'Số hai'
// }

// docSo['1']