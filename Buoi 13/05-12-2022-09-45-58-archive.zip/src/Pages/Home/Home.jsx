import React from 'react'
import { Carousel } from 'antd';
import { useSelector, useDispatch } from 'react-redux'
import ShoesCard from '../../Components/ShoesCard/ShoesCard';
import { useEffect } from 'react';
import axios from 'axios';
import { getProductApi } from '../../redux/reducers/productReducer';
const contentStyle = {
  margin: 0,
  height: '260px',
  color: '#fff',
  lineHeight: '160px',
  textAlign: 'center',
  background: '#364d79',
};


const Home = () => {
  const { arrProduct } = useSelector(state => state.productReducer);
  const dispatch = useDispatch();
  const onChange = (currentSlide) => {
    console.log(currentSlide);
  };

  const getAllProductApi = async () => {
    // const result = await axios({
    //   url:'https://shop.cyberlearn.vn/api/product',
    //   method:'GET'
    // });
    // //dispatch action lên reducer
    // const action = {
    //   type:'productReducer/getAllProductApi',
    //   payload:result.data.content
    // };
    //Redux 2 loại action
    /*
      action1: {type,payload}
      action2: async function (dispatch2) { xử lý => dispatch2(redux)}
    
    */

      const action = getProductApi();
    
    dispatch(action);
  }

  useEffect(() => {
    //call api
    getAllProductApi();
  }, []);
  return (
    <>
      <Carousel afterChange={onChange} effect="scrollx">
        <div>
          <h3 style={contentStyle}>
            <img src='https://picsum.photos/id/1/1000/260' alt="..." width={'100%'} style={{ objectFit: 'cover' }} />
          </h3>
        </div>
        <div>
          <h3 style={contentStyle}>
            <img src='https://picsum.photos/id/2/1000/260' alt="..." width={'100%'} style={{ objectFit: 'cover' }} />

          </h3>
        </div>
        <div>
          <h3 style={contentStyle}>
            <img src='https://picsum.photos/id/3/1000/260' alt="..." width={'100%'} style={{ objectFit: 'cover' }} />

          </h3>
        </div>

      </Carousel>

      <h3 className='text-center display-4'>Product Feature</h3>
      <div className='row'>
        {arrProduct.map((item, index) => {
          return <div className='col-3' key={index}>
            <ShoesCard prod={item} />
          </div>
        })}
      </div>
    </>


  );
}

export default Home