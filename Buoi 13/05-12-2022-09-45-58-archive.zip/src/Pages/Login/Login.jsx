import React from 'react'
import {useFormik} from 'formik';
import * as yup from 'yup'
import { loginApi } from '../../redux/reducers/userReducer';
import { useDispatch } from 'react-redux';
const Login = () => {
  const dispatch = useDispatch();
  const form = useFormik({
    initialValues:{
      email:'',
      password:''
    },
    validationSchema:yup.object().shape({
      email:yup.string().required('email cannot be blank!').email('email is invalid!'),
      password:yup.string().required('password cannot be blank!')
    }),
    onSubmit: (values) => {
      const actionAsync = loginApi(values);
      dispatch(actionAsync);
    }
  })
  return (
    <form className='container' onSubmit={form.handleSubmit}>
      <h3>Login</h3>
      <div className='form-group'>
        <p>email</p>
        <input className='form-control' name="email" onChange={form.handleChange} onBlur={form.handleBlur}/>
        {form.errors.email && <p className='text-danger'>{form.errors.email}</p>}
      </div>
      <div className='form-group'>
        <p>password</p>
        <input className='form-control' name="password" onChange={form.handleChange}   onBlur={form.handleBlur}/>
        {form.errors.password && <p className='text-danger'>{form.errors.password}</p>}

      </div>
      <div className='form-group'>
        <button className='btn btn-success mt-2' type='submit'>Login</button>
      </div>
    </form>
  )
}

export default Login