import React from 'react'
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux'
import { getProfileApi } from '../../redux/reducers/userReducer';

const Profile = () => {
  const {userProfile} = useSelector(state => state.userReducer);
  const dispatch = useDispatch();

  useEffect(()=>{
    const actionAsync = getProfileApi();
    dispatch(actionAsync);

  },[])



  return (
    <div className='container'>
      <div className='row'>
        <div className='col-4'>
          <img src={userProfile?.avatar} alt="..." className='w-100' />
        </div>
        <div className='col-4'>
          <p>Profile: {userProfile?.name}</p>
        </div>
      </div>
    </div>
  )
}

export default Profile