import React, { Component } from 'react'

export default class Footer extends Component {
  render() {
    return (
        <div className='bg-primary text-white text-center p-5'>Footer</div>
    )
  }
}
