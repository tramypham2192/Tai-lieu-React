import React from 'react'

const Carts = () => {
  return (
    <div>Carts</div>
  )
}

export default Carts